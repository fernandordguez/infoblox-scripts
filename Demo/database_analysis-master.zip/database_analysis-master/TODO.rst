 ToDo:
  [x] Reports for counters
  [x] Reports for member counters
  [p] Summary Report
    [x] Counters, Members and Features
    [x] Summary DataFrames
    [ ] Enhanced Features
  [x] Convert datestamp to ISO YYYYMMDD-HHMMss
  [x] Allow for direct processing of xml file
  [ ] Convert DHCPOPTION functions to use XML parsing (instead of regex)
  [x] Add Network View to network report for options and /32s
